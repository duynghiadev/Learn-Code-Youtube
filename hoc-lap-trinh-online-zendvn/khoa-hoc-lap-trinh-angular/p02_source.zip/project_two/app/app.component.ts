import { Component } from '@angular/core';


@Component({
	selector: 'my-app',
	template: `<proj-style></proj-style>`
})


export class AppComponent { }
