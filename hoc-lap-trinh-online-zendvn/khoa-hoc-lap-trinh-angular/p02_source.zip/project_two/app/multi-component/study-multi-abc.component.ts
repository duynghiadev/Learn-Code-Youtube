import { Component } from '@angular/core';

@Component({
	selector: 'my-study-multi-abc',
	template: '<h1>Study Multi ABC</h1>'
})

export class StudyMultiAbcComponent  {
	
}