import { Component } from '@angular/core';


@Component({
	selector: 'my-sub',
	template: '<h3 style="color:red;">Subcomponent</h3>'
})

export class SubComponent {

}
